# Veloma Consents App

## Included
- urls.py with DRF router
- ViewSets for terms and consents
- Nested serializers for consent detail
- Public signing endpoints
- Audit and evidence export endpoints
- Event chain service
- Basic evidence generation service
- Celery tasks scaffold
- Admin registrations

## Integrate in core/settings.py
```python
INSTALLED_APPS += ["consents"]
```

## Integrate in core/urls.py
```python
from django.urls import include, path

urlpatterns += [
    path("api/consents/", include("consents.urls")),
]
```

## Notes
This package is a stronger scaffold and integration baseline.
Cryptographic PKI signing, RFC3161 timestamp, Merkle batching and blockchain anchoring still need dedicated implementation.
