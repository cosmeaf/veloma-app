from rest_framework import serializers
from consents.models import ConsentVersion


class ConsentVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = ConsentVersion
        fields = "__all__"

        read_only_fields = (
            "id",
            "content_hash_snapshot",
            "created_at",
        )

        depth = 2