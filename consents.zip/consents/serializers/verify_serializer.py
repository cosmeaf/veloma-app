from rest_framework import serializers


class VerifyConsentSerializer(serializers.Serializer):

    document_hash = serializers.CharField(
        max_length=64
    )