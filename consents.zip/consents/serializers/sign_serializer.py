from rest_framework import serializers


class SignConsentSerializer(serializers.Serializer):
    token = serializers.CharField()
    device_fingerprint = serializers.CharField()
    user_agent = serializers.CharField()
    ip_address = serializers.IPAddressField()
    screen_resolution = serializers.CharField()
    timezone = serializers.CharField()
    language = serializers.CharField()