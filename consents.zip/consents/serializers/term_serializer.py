from rest_framework import serializers
from consents.models import Term


class TermSerializer(serializers.ModelSerializer):

    class Meta:
        model = Term
        fields = "__all__"
        read_only_fields = (
            "id",
            "created_at",
            "updated_at",
        )