from rest_framework import serializers
from consents.models import Consent
from .consent_version_serializer import ConsentVersionSerializer
from .consent_event_serializer import ConsentEventSerializer
from .consent_evidence_serializer import ConsentEvidenceSerializer


class ConsentSerializer(serializers.ModelSerializer):

    accepted_terms = ConsentVersionSerializer(
        many=True,
        read_only=True
    )

    events = ConsentEventSerializer(
        many=True,
        read_only=True
    )

    evidence = ConsentEvidenceSerializer(
        read_only=True
    )

    class Meta:
        model = Consent

        fields = "__all__"

        read_only_fields = (
            "id",
            "token_hash",
            "opened_at",
            "signed_at",
            "ip_open",
            "ip_signed",
            "user_agent_open",
            "user_agent_signed",
            "device_fingerprint",
            "email_sent_at",
            "last_email_sent",
            "created_at",
        )

        depth = 1

    def validate(self, attrs):

        request = self.context["request"]
        user = request.user

        # Superuser bypass
        if user.is_superuser:
            return attrs

        # owner validation
        if attrs.get("owner") != user:
            raise serializers.ValidationError(
                "You can only create consents for yourself."
            )

        return attrs