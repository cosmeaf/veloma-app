from rest_framework import serializers
from consents.models import ConsentEvent


class ConsentEventSerializer(serializers.ModelSerializer):

    class Meta:
        model = ConsentEvent
        fields = "__all__"

        read_only_fields = (
            "id",
            "previous_hash",
            "event_hash",
            "created_at",
        )

        depth = 1