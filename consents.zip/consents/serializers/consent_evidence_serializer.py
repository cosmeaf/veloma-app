from rest_framework import serializers
from consents.models import ConsentEvidence


class ConsentEvidenceSerializer(serializers.ModelSerializer):

    class Meta:
        model = ConsentEvidence
        fields = "__all__"

        read_only_fields = (
            "id",
            "document_hash_sha256",
            "document_signature",
            "timestamp_token",
            "terms_hash_snapshot",
            "merkle_leaf_hash",
            "blockchain_anchor_tx",
            "created_at",
        )

        depth = 1