from rest_framework import serializers
from consents.models import TermVersion


class TermVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = TermVersion
        fields = "__all__"

        read_only_fields = (
            "id",
            "content_hash",
            "created_at",
        )

        depth = 1