from celery import shared_task

from consents.models import Consent, ConsentEvidence
from consents.services.evidence_service import EvidenceService
from consents.services.event_chain_service import EventChainService


@shared_task
def build_missing_evidence(consent_id):
    consent = Consent.objects.select_related("term_version", "evidence").get(pk=consent_id)
    if getattr(consent, "evidence", None):
        return {"detail": "Evidence already exists"}
    snapshot = {
        "task_generated": True,
        "accepted_term_hash": consent.term_version.content_hash,
    }
    evidence = EvidenceService.create_or_update_evidence(consent, snapshot)
    EventChainService.append_event(consent, "integrity_verified", {"document_hash": evidence.document_hash_sha256})
    return {"document_hash": evidence.document_hash_sha256}


@shared_task
def verify_evidence_integrity():
    processed = 0
    for evidence in ConsentEvidence.objects.select_related("consent").all():
        processed += 1
        EventChainService.append_event(
            evidence.consent,
            "integrity_verified",
            {"document_hash": evidence.document_hash_sha256},
        )
    return {"processed": processed}
