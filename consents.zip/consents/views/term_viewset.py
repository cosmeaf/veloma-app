from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated

from consents.models import Term, TermVersion
from consents.serializers import (
    TermSerializer,
    TermVersionSerializer
)

from core.permissions import IsStaffOrAdmin


class TermViewSet(ModelViewSet):

    queryset = Term.objects.all()

    serializer_class = TermSerializer

    permission_classes = [
        IsAuthenticated,
        IsStaffOrAdmin,
    ]


class TermVersionViewSet(ModelViewSet):

    queryset = TermVersion.objects.all()

    serializer_class = TermVersionSerializer

    permission_classes = [
        IsAuthenticated,
        IsStaffOrAdmin,
    ]