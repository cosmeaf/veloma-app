from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated

from consents.models import Consent
from consents.serializers import ConsentSerializer

from core.permissions import IsStaffOrAdmin


class ConsentViewSet(ModelViewSet):

    serializer_class = ConsentSerializer

    permission_classes = [
        IsAuthenticated,
        IsStaffOrAdmin,
    ]

    def get_queryset(self):

        user = self.request.user

        if user.is_superuser:
            return Consent.objects.all()

        return Consent.objects.filter(owner=user)

    def perform_create(self, serializer):

        user = self.request.user

        if user.is_superuser:
            serializer.save()

        else:
            serializer.save(owner=user)