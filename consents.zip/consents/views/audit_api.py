from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from consents.models import Consent
from consents.serializers import ConsentSerializer

from core.permissions import IsStaffOrAdmin


class AuditAPI(APIView):

    permission_classes = [
        IsAuthenticated,
        IsStaffOrAdmin,
    ]

    def get(self, request, consent_id):

        try:

            consent = Consent.objects.get(id=consent_id)

        except Consent.DoesNotExist:

            return Response(
                {"error": "Consent not found"},
                status=404
            )

        if not request.user.is_superuser:

            if consent.owner != request.user:
                return Response(
                    {"error": "Forbidden"},
                    status=403
                )

        serializer = ConsentSerializer(consent)

        return Response(serializer.data)