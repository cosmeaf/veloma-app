from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from consents.models import ConsentEvidence
from core.permissions import IsStaffOrAdmin


class EvidenceExportAPI(APIView):

    permission_classes = [
        IsAuthenticated,
        IsStaffOrAdmin,
    ]

    def get(self, request, consent_id):

        try:

            evidence = ConsentEvidence.objects.get(
                consent_id=consent_id
            )

        except ConsentEvidence.DoesNotExist:

            return Response(
                {"error": "Evidence not found"},
                status=404
            )

        consent = evidence.consent

        if not request.user.is_superuser:

            if consent.owner != request.user:
                return Response(
                    {"error": "Forbidden"},
                    status=403
                )

        return Response(
            {
                "document_hash": evidence.document_hash_sha256,
                "merkle_leaf": evidence.merkle_leaf_hash,
                "blockchain_tx": evidence.blockchain_anchor_tx,
                "timestamp": evidence.created_at,
            }
        )