from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from consents.models import Consent
from consents.serializers import ConsentSerializer


class PublicConsentAPI(APIView):

    authentication_classes = []
    permission_classes = []

    def get(self, request, token):

        try:

            consent = Consent.objects.get(token_hash=token)

        except Consent.DoesNotExist:

            return Response(
                {"error": "Invalid token"},
                status=status.HTTP_404_NOT_FOUND
            )

        serializer = ConsentSerializer(consent)

        return Response(serializer.data)