from rest_framework.views import APIView
from rest_framework.response import Response

from consents.models import ConsentEvidence
from consents.serializers import VerifyConsentSerializer


class VerificationAPI(APIView):

    authentication_classes = []
    permission_classes = []

    def post(self, request):

        serializer = VerifyConsentSerializer(data=request.data)

        serializer.is_valid(raise_exception=True)

        document_hash = serializer.validated_data["document_hash"]

        exists = ConsentEvidence.objects.filter(
            document_hash_sha256=document_hash
        ).exists()

        return Response(
            {
                "valid": exists
            }
        )