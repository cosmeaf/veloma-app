from django.urls import path, include
from rest_framework.routers import DefaultRouter

from consents.views import (
    TermViewSet,
    TermVersionViewSet,
    ConsentViewSet,
    PublicConsentAPI,
    VerificationAPI,
    AuditAPI,
    EvidenceExportAPI,
)

router = DefaultRouter()

# INTERNAL APIs
router.register(r"terms", TermViewSet, basename="terms")
router.register(r"term-versions", TermVersionViewSet, basename="term-versions")
router.register(r"consents", ConsentViewSet, basename="consents")


urlpatterns = [

    # Router APIs
    path("", include(router.urls)),

    # PUBLIC CONSENT
    path(
        "public/consent/<str:token>/",
        PublicConsentAPI.as_view(),
        name="public-consent",
    ),

    # PUBLIC VERIFICATION
    path(
        "public/consents/verify/",
        VerificationAPI.as_view(),
        name="verify-consent",
    ),

    # AUDIT API
    path(
        "consents/<uuid:consent_id>/audit/",
        AuditAPI.as_view(),
        name="consent-audit",
    ),

    # EVIDENCE EXPORT
    path(
        "consents/<uuid:consent_id>/evidence/",
        EvidenceExportAPI.as_view(),
        name="consent-evidence",
    ),
]