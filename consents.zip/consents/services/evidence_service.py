import io
import json
from zipfile import ZipFile

from django.template.loader import render_to_string
from django.utils import timezone

from consents.models import ConsentEvidence
from consents.services.crypto_service import CryptoService
from consents.services.storage_service import StorageService


class EvidenceService:
    @staticmethod
    def build_snapshot(consent, request, device_data: dict, ipintel_data: dict) -> dict:
        return {
            "timestamp": timezone.now().isoformat(),
            "client_name": consent.client_name,
            "client_email": consent.client_email,
            "client_tax_id": consent.client_tax_id,
            "client_company": consent.client_company,
            "client_phone": consent.client_phone,
            "ip_address": request.META.get("REMOTE_ADDR"),
            "user_agent": request.META.get("HTTP_USER_AGENT", ""),
            "network": ipintel_data,
            "device": device_data,
            "accepted_term_version_id": consent.term_version_id,
            "accepted_term_title": consent.term_version.title,
            "accepted_term_hash": consent.term_version.content_hash,
        }

    @staticmethod
    def render_pdf_like_html(consent) -> bytes:
        html = render_to_string("consents/consent_pdf.html", {"consent": consent})
        return html.encode("utf-8")

    @staticmethod
    def create_or_update_evidence(consent, snapshot: dict):
        payload = EvidenceService.render_pdf_like_html(consent)
        document_hash = CryptoService.sha256_bytes(payload)
        s3_key = f"consents/{consent.id}/consent_document.html"
        StorageService().upload_bytes(s3_key, payload, content_type="text/html")

        evidence, _ = ConsentEvidence.objects.update_or_create(
            consent=consent,
            defaults={
                "document_s3_key": s3_key,
                "document_hash_sha256": document_hash,
                "document_signature": "",
                "timestamp_token": "",
                "terms_hash_snapshot": consent.term_version.content_hash,
                "snapshot_json": snapshot,
                "merkle_leaf_hash": "",
                "blockchain_anchor_tx": "",
            },
        )
        return evidence

    @staticmethod
    def build_evidence_zip(consent) -> bytes:
        evidence = consent.evidence
        buffer = io.BytesIO()
        with ZipFile(buffer, "w") as zf:
            zf.writestr("snapshot.json", json.dumps(evidence.snapshot_json, indent=2, ensure_ascii=False))
            zf.writestr("hash.txt", evidence.document_hash_sha256)
            zf.writestr("s3_key.txt", evidence.document_s3_key)
            zf.writestr("terms_hash.txt", evidence.terms_hash_snapshot or "")
        return buffer.getvalue()
