import io

from django.conf import settings
from minio import Minio


class StorageService:
    bucket = "consent-evidence"

    def __init__(self):
        self.client = Minio(
            settings.MINIO_ENDPOINT,
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=getattr(settings, "MINIO_SECURE", False),
        )

    def upload_bytes(self, key: str, payload: bytes, content_type: str = "application/octet-stream") -> None:
        stream = io.BytesIO(payload)
        self.client.put_object(
            bucket_name=self.bucket,
            object_name=key,
            data=stream,
            length=len(payload),
            content_type=content_type,
        )

    def get_presigned_url(self, key: str, expires_seconds: int = 3600):
        from datetime import timedelta
        return self.client.presigned_get_object(self.bucket, key, expires=timedelta(seconds=expires_seconds))
