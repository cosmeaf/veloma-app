from consents.models import ConsentEvent


class EventChainService:
    @staticmethod
    def append_event(consent, event_type: str, metadata: dict | None = None):
        last_event = consent.events.order_by("-created_at", "-id").first()
        previous_hash = last_event.event_hash if last_event else ""
        metadata = metadata or {}
        event_hash = ConsentEvent.compute_event_hash(
            consent_id=consent.id,
            event_type=event_type,
            previous_event_hash=previous_hash,
            metadata=metadata,
        )
        return ConsentEvent.objects.create(
            consent=consent,
            event_type=event_type,
            previous_event_hash=previous_hash,
            event_hash=event_hash,
            metadata=metadata,
        )
