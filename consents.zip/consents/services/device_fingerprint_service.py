class DeviceFingerprintService:
    @staticmethod
    def build_snapshot(validated_data):
        return {
            "device_fingerprint": validated_data.get("device_fingerprint", ""),
            "screen_resolution": validated_data.get("screen_resolution", ""),
            "timezone": validated_data.get("timezone", ""),
            "language": validated_data.get("language", ""),
            "canvas_fingerprint": validated_data.get("canvas_fingerprint", ""),
        }
