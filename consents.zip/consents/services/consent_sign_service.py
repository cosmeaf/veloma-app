from django.utils import timezone

from consents.models import Consent
from consents.services.crypto_service import CryptoService
from consents.services.device_fingerprint_service import DeviceFingerprintService
from consents.services.evidence_service import EvidenceService
from consents.services.event_chain_service import EventChainService
from consents.services.ipintel_service import IpIntelService


class InvalidConsentToken(Exception):
    pass


class ConsentSignService:
    @staticmethod
    def register_open(consent: Consent, request):
        update_fields = []
        if consent.status in [Consent.STATUS_PENDING, Consent.STATUS_SENT]:
            consent.status = Consent.STATUS_OPENED
            update_fields.append("status")
        if not consent.opened_at:
            consent.opened_at = timezone.now()
            update_fields.append("opened_at")
        if not consent.ip_open:
            consent.ip_open = request.META.get("REMOTE_ADDR")
            update_fields.append("ip_open")
        if not consent.user_agent_open:
            consent.user_agent_open = request.META.get("HTTP_USER_AGENT", "")
            update_fields.append("user_agent_open")
        if update_fields:
            consent.save(update_fields=update_fields)
            EventChainService.append_event(
                consent,
                "consent_opened",
                {"ip": consent.ip_open},
            )
        return consent

    @staticmethod
    def sign(consent: Consent, token: str, validated_data: dict, request):
        hashed_token = CryptoService.hash_token(token)
        if not consent.token_hash or hashed_token != consent.token_hash:
            raise InvalidConsentToken("Invalid token")

        device_data = DeviceFingerprintService.build_snapshot(validated_data)
        ipintel_data = IpIntelService.analyze(request.META.get("REMOTE_ADDR"))
        snapshot = EvidenceService.build_snapshot(
            consent=consent,
            request=request,
            device_data=device_data,
            ipintel_data=ipintel_data,
        )
        evidence = EvidenceService.create_or_update_evidence(consent, snapshot)

        consent.status = Consent.STATUS_SIGNED
        consent.signed_at = timezone.now()
        consent.ip_signed = request.META.get("REMOTE_ADDR")
        consent.user_agent_signed = request.META.get("HTTP_USER_AGENT", "")
        consent.device_fingerprint = validated_data.get("device_fingerprint", "")
        consent.token_hash = ""
        consent.save(
            update_fields=[
                "status",
                "signed_at",
                "ip_signed",
                "user_agent_signed",
                "device_fingerprint",
                "token_hash",
            ]
        )

        EventChainService.append_event(
            consent,
            "consent_signed",
            {
                "document_hash": evidence.document_hash_sha256,
                "device_fingerprint": consent.device_fingerprint,
            },
        )
        return consent, evidence
