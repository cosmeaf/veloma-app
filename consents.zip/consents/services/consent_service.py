from django.conf import settings
from django.urls import reverse
from django.utils import timezone

from services.email.email_service import EmailService

from consents.models import Consent
from consents.services.crypto_service import CryptoService
from consents.services.event_chain_service import EventChainService


class ConsentService:
    @staticmethod
    def create_consent(owner, validated_data):
        public_token = CryptoService.generate_public_token()
        token_hash = CryptoService.hash_token(public_token)
        consent = Consent.objects.create(
            owner=owner,
            token_hash=token_hash,
            **validated_data,
        )
        EventChainService.append_event(consent, "consent_created", {"owner_id": owner.id})
        consent._public_token = public_token
        return consent

    @staticmethod
    def build_public_link(request, consent):
        return request.build_absolute_uri(
            reverse("consents:public-consent-detail", kwargs={"consent_id": consent.id})
        )

    @staticmethod
    def send_consent_email(request, consent):
        public_link = ConsentService.build_public_link(request, consent)
        token = getattr(consent, "_public_token", None)
        context = {
            "consent": consent,
            "public_link": public_link,
            "public_token": token,
        }

        # Adapt this call if your EmailService signature differs.
        EmailService.send_email(
            to=[consent.client_email],
            subject="Consent request",
            template_name="consents/email_consent_request.html",
            context=context,
        )

        now = timezone.now()
        consent.status = Consent.STATUS_SENT
        consent.email_sent_at = now if not consent.email_sent_at else consent.email_sent_at
        consent.last_email_sent = now
        consent.save(update_fields=["status", "email_sent_at", "last_email_sent"])
        EventChainService.append_event(consent, "email_sent", {"client_email": consent.client_email})
        return consent
