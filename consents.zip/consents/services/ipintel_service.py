import sys
from pathlib import Path

IPINTEL_PATH = Path("/opt/ipintel")
if IPINTEL_PATH.exists():
    sys.path.append(str(IPINTEL_PATH))


class IpIntelService:
    @staticmethod
    def analyze(ip_address: str) -> dict:
        try:
            from ipintel import analyze_ip  # type: ignore
            data = analyze_ip(ip_address)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {
                "ip": ip_address,
                "country": "",
                "asn": "",
                "vpn": False,
                "proxy": False,
                "risk_score": 0,
            }
