import uuid
import hashlib
import json

from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone


class ConsentEvent(models.Model):
    """
    Registro de auditoria encadeado criptograficamente.

    Cada evento contém o hash do evento anterior, criando
    uma cadeia inviolável (tamper-evident).
    """

    EVENT_CREATED = "created"
    EVENT_EMAIL_SENT = "email_sent"
    EVENT_OPENED = "opened"
    EVENT_SIGNED = "signed"
    EVENT_REVOKED = "revoked"
    EVENT_VERIFIED = "verified"
    EVENT_TAMPER_CHECK = "tamper_check"

    EVENT_TYPES = [
        (EVENT_CREATED, "Consent Created"),
        (EVENT_EMAIL_SENT, "Email Sent"),
        (EVENT_OPENED, "Consent Opened"),
        (EVENT_SIGNED, "Consent Signed"),
        (EVENT_REVOKED, "Consent Revoked"),
        (EVENT_VERIFIED, "Evidence Verified"),
        (EVENT_TAMPER_CHECK, "Integrity Check"),
    ]

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )

    consent = models.ForeignKey(
        "consents.Consent",
        on_delete=models.CASCADE,
        related_name="events"
    )

    event_type = models.CharField(
        max_length=50,
        choices=EVENT_TYPES,
        db_index=True
    )

    metadata = models.JSONField(
        null=True,
        blank=True,
        help_text="Dados adicionais do evento"
    )

    previous_hash = models.CharField(
        max_length=64,
        blank=True,
        help_text="Hash do evento anterior"
    )

    event_hash = models.CharField(
        max_length=64,
        db_index=True,
        editable=False
    )

    created_at = models.DateTimeField(
        default=timezone.now,
        db_index=True
    )

    class Meta:
        db_table = "consent_events"

        verbose_name = "Evento de Consentimento"
        verbose_name_plural = "Eventos de Consentimento"

        ordering = ["created_at"]

        indexes = [
            models.Index(fields=["consent", "created_at"]),
            models.Index(fields=["event_hash"]),
        ]

    def __str__(self):
        return f"{self.consent_id} - {self.event_type}"

    # ------------------------------------------------------------
    # HASH CHAIN GENERATION
    # ------------------------------------------------------------

    def generate_hash(self):

        payload = {
            "consent_id": str(self.consent_id),
            "event_type": self.event_type,
            "metadata": self.metadata,
            "previous_hash": self.previous_hash,
            "created_at": self.created_at.isoformat()
        }

        payload_json = json.dumps(payload, sort_keys=True)

        return hashlib.sha256(payload_json.encode()).hexdigest()

    # ------------------------------------------------------------
    # SAVE
    # ------------------------------------------------------------

    def save(self, *args, **kwargs):

        if not self.previous_hash:

            last_event = (
                ConsentEvent.objects
                .filter(consent=self.consent)
                .order_by("-created_at")
                .first()
            )

            if last_event:
                self.previous_hash = last_event.event_hash

        if not self.event_hash:
            self.event_hash = self.generate_hash()

        super().save(*args, **kwargs)

    # ------------------------------------------------------------
    # SECURITY RULES
    # ------------------------------------------------------------

    def delete(self, *args, **kwargs):
        raise ValidationError(
            "Eventos de auditoria não podem ser deletados."
        )