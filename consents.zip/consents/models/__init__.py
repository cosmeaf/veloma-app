"""
Consents Models Package

Central export point for all models in the consents application.
This allows importing models directly from:

    from consents.models import Consent

instead of:

    from consents.models.consent import Consent
"""

# Core legal structures
from .term import Term
from .term_version import TermVersion

# Consent lifecycle
from .consent import Consent
from .consent_version import ConsentVersion

# Evidence layer
from .consent_evidence import ConsentEvidence

# Audit / forensic chain
from .consent_event import ConsentEvent


__all__ = (
    "Term",
    "TermVersion",
    "Consent",
    "ConsentVersion",
    "ConsentEvidence",
    "ConsentEvent",
)