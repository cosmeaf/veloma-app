import uuid
from django.db import models
from django.core.exceptions import ValidationError


class Term(models.Model):
    """
    Entidade raiz que representa um documento legal versionado.

    Exemplo:
    "Termo de Autorização para Processamento de Dados Contábeis"

    Este modelo NÃO contém o texto legal.
    O conteúdo imutável está em TermVersion.
    """

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
        help_text="Identificador único global do termo"
    )

    name = models.CharField(
        max_length=200,
        unique=True,
        db_index=True,
        verbose_name="Nome do Termo",
        help_text="Nome descritivo do conjunto de termos"
    )

    description = models.TextField(
        blank=True,
        verbose_name="Descrição",
        help_text="Explicação do propósito jurídico deste termo"
    )

    active = models.BooleanField(
        default=True,
        db_index=True,
        help_text="Define se o termo está disponível para novos consentimentos"
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True
    )

    updated_at = models.DateTimeField(
        auto_now=True
    )

    class Meta:
        db_table = "consent_terms"

        verbose_name = "Termo Legal"
        verbose_name_plural = "Termos Legais"

        ordering = ["-created_at"]

        indexes = [
            models.Index(fields=["name"]),
            models.Index(fields=["active"]),
        ]

    def __str__(self):
        return f"{self.name}"

    # ------------------------------------------------------------------
    # SECURITY RULES
    # ------------------------------------------------------------------

    def delete(self, *args, **kwargs):
        """
        Termos legais nunca devem ser removidos fisicamente.
        Apenas desativados.
        """
        raise ValidationError(
            "Termos legais não podem ser deletados. Utilize active=False."
        )

    # ------------------------------------------------------------------
    # BUSINESS LOGIC
    # ------------------------------------------------------------------

    def get_active_version(self):
        """
        Retorna a versão ativa atual do termo.
        Deve existir apenas UMA versão ativa.
        """

        versions = self.versions.filter(active=True)

        if versions.count() > 1:
            raise ValidationError(
                "Erro de integridade: múltiplas versões ativas detectadas."
            )

        return versions.first()