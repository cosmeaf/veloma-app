import uuid
import hashlib

from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone


class TermVersion(models.Model):
    """
    Versão imutável de um termo legal.

    Cada alteração no texto gera uma nova versão.
    O conteúdo nunca pode ser modificado após criação.
    """

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )

    term = models.ForeignKey(
        "consents.Term",
        on_delete=models.PROTECT,
        related_name="versions",
        db_index=True
    )

    version = models.PositiveIntegerField(
        help_text="Número sequencial da versão"
    )

    title = models.CharField(
        max_length=255,
        help_text="Título da versão do termo"
    )

    content = models.TextField(
        help_text="Conteúdo completo do termo legal"
    )

    content_hash = models.CharField(
        max_length=64,
        editable=False,
        db_index=True,
        help_text="SHA256 do conteúdo do termo"
    )

    active = models.BooleanField(
        default=False,
        db_index=True,
        help_text="Define se esta é a versão ativa do termo"
    )

    created_at = models.DateTimeField(
        default=timezone.now,
        db_index=True
    )

    class Meta:
        db_table = "consent_term_versions"

        verbose_name = "Versão de Termo"
        verbose_name_plural = "Versões de Termos"

        ordering = ["-version"]

        unique_together = ("term", "version")

        indexes = [
            models.Index(fields=["term", "version"]),
            models.Index(fields=["content_hash"]),
            models.Index(fields=["active"]),
        ]

    def __str__(self):
        return f"{self.term.name} v{self.version}"

    # ------------------------------------------------------------
    # SECURITY CONTROLS
    # ------------------------------------------------------------

    def delete(self, *args, **kwargs):
        """
        Versões legais nunca devem ser deletadas.
        """
        raise ValidationError(
            "Versões de termos não podem ser removidas."
        )

    # ------------------------------------------------------------
    # HASH GENERATION
    # ------------------------------------------------------------

    def generate_content_hash(self):
        """
        Calcula SHA256 do conteúdo do termo.
        """
        return hashlib.sha256(
            self.content.encode("utf-8")
        ).hexdigest()

    # ------------------------------------------------------------
    # VALIDATION
    # ------------------------------------------------------------

    def clean(self):
        """
        Garante consistência lógica.
        """

        # garantir apenas uma versão ativa por termo
        if self.active:
            existing = TermVersion.objects.filter(
                term=self.term,
                active=True
            ).exclude(id=self.id)

            if existing.exists():
                raise ValidationError(
                    "Já existe uma versão ativa para este termo."
                )

    # ------------------------------------------------------------
    # SAVE
    # ------------------------------------------------------------

    def save(self, *args, **kwargs):

        # gerar hash apenas na criação
        if not self.content_hash:
            self.content_hash = self.generate_content_hash()

        super().save(*args, **kwargs)