import uuid
import hashlib

from django.db import models
from django.core.exceptions import ValidationError


class ConsentVersion(models.Model):
    """
    Snapshot das versões de termos aceitas pelo cliente.

    Este modelo congela exatamente quais versões de termos
    estavam em vigor no momento da assinatura.
    """

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )

    consent = models.ForeignKey(
        "consents.Consent",
        on_delete=models.CASCADE,
        related_name="accepted_terms"
    )

    term = models.ForeignKey(
        "consents.Term",
        on_delete=models.PROTECT
    )

    term_version = models.ForeignKey(
        "consents.TermVersion",
        on_delete=models.PROTECT
    )

    # ------------------------------------------------------------
    # SNAPSHOT DATA
    # ------------------------------------------------------------

    term_title_snapshot = models.CharField(
        max_length=255,
        help_text="Título do termo no momento da assinatura"
    )

    content_hash_snapshot = models.CharField(
        max_length=64,
        db_index=True,
        help_text="Hash SHA256 do conteúdo aceito"
    )

    # ------------------------------------------------------------
    # AUDIT
    # ------------------------------------------------------------

    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True
    )

    class Meta:
        db_table = "consent_versions"

        verbose_name = "Versão Aceita do Termo"
        verbose_name_plural = "Versões Aceitas dos Termos"

        unique_together = ("consent", "term_version")

        indexes = [
            models.Index(fields=["consent"]),
            models.Index(fields=["content_hash_snapshot"]),
        ]

    def __str__(self):
        return f"{self.consent_id} - {self.term.name} v{self.term_version.version}"

    # ------------------------------------------------------------
    # HASH GENERATION
    # ------------------------------------------------------------

    def generate_hash(self):

        payload = f"{self.term_version_id}{self.term_title_snapshot}"

        return hashlib.sha256(payload.encode()).hexdigest()

    # ------------------------------------------------------------
    # VALIDATION
    # ------------------------------------------------------------

    def clean(self):

        if self.term_version.term_id != self.term_id:
            raise ValidationError(
                "A versão do termo não pertence ao termo informado."
            )

    # ------------------------------------------------------------
    # SECURITY RULES
    # ------------------------------------------------------------

    def delete(self, *args, **kwargs):
        raise ValidationError(
            "Snapshots de termos aceitos não podem ser deletados."
        )