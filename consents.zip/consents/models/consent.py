import uuid
import hashlib
from django.conf import settings
from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone


class Consent(models.Model):
    """
    Representa um pedido de autorização legal enviado ao cliente.

    Após a assinatura, este objeto torna-se parte do registro
    jurídico permanente do sistema.
    """

    STATUS_PENDING = "pending"
    STATUS_SENT = "sent"
    STATUS_OPENED = "opened"
    STATUS_SIGNED = "signed"
    STATUS_EXPIRED = "expired"
    STATUS_REVOKED = "revoked"

    STATUS_CHOICES = [
        (STATUS_PENDING, "Pending"),
        (STATUS_SENT, "Sent"),
        (STATUS_OPENED, "Opened"),
        (STATUS_SIGNED, "Signed"),
        (STATUS_EXPIRED, "Expired"),
        (STATUS_REVOKED, "Revoked"),
    ]

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )

    token_hash = models.CharField(
        max_length=128,
        null=True,
        blank=True,
        db_index=True,
        help_text="Hash SHA256 do token de acesso"
    )

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="consents"
    )

    # ------------------------------------------------------------
    # CLIENT DATA
    # ------------------------------------------------------------

    client_name = models.CharField(max_length=255)

    client_email = models.EmailField(
        db_index=True
    )

    client_tax_id = models.CharField(
        max_length=50,
        db_index=True
    )

    client_company = models.CharField(
        max_length=255,
        blank=True
    )

    client_phone = models.CharField(
        max_length=50,
        blank=True
    )

    # ------------------------------------------------------------
    # STATUS
    # ------------------------------------------------------------

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_PENDING,
        db_index=True
    )

    expires_at = models.DateTimeField(
        db_index=True
    )

    # ------------------------------------------------------------
    # TIMESTAMPS
    # ------------------------------------------------------------

    opened_at = models.DateTimeField(
        null=True,
        blank=True
    )

    signed_at = models.DateTimeField(
        null=True,
        blank=True
    )

    # ------------------------------------------------------------
    # NETWORK ATTRIBUTION
    # ------------------------------------------------------------

    ip_open = models.GenericIPAddressField(
        null=True,
        blank=True
    )

    ip_signed = models.GenericIPAddressField(
        null=True,
        blank=True
    )

    user_agent_open = models.TextField(
        blank=True
    )

    user_agent_signed = models.TextField(
        blank=True
    )

    device_fingerprint = models.CharField(
        max_length=128,
        blank=True,
        db_index=True
    )

    # ------------------------------------------------------------
    # EMAIL TRACKING
    # ------------------------------------------------------------

    email_sent_at = models.DateTimeField(
        null=True,
        blank=True
    )

    last_email_sent = models.DateTimeField(
        null=True,
        blank=True
    )

    # ------------------------------------------------------------
    # AUDIT
    # ------------------------------------------------------------

    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True
    )

    class Meta:
        db_table = "consents"

        ordering = ["-created_at"]

        indexes = [
            models.Index(fields=["status"]),
            models.Index(fields=["client_email"]),
            models.Index(fields=["client_tax_id"]),
            models.Index(fields=["created_at"]),
        ]

    def __str__(self):
        return f"{self.client_email} - {self.status}"

    # ------------------------------------------------------------
    # TOKEN SECURITY
    # ------------------------------------------------------------

    def set_token(self, raw_token):
        """
        Armazena apenas o hash do token.
        """
        self.token_hash = hashlib.sha256(
            raw_token.encode()
        ).hexdigest()

    def verify_token(self, raw_token):

        if not self.token_hash:
            return False

        return hashlib.sha256(
            raw_token.encode()
        ).hexdigest() == self.token_hash

    # ------------------------------------------------------------
    # STATUS HELPERS
    # ------------------------------------------------------------

    def is_expired(self):

        if self.expires_at and timezone.now() > self.expires_at:
            return True

        return False

    def can_be_signed(self):

        if self.status in [
            self.STATUS_SIGNED,
            self.STATUS_REVOKED,
        ]:
            return False

        if self.is_expired():
            return False

        return True

    # ------------------------------------------------------------
    # SECURITY RULES
    # ------------------------------------------------------------

    def clean(self):

        if self.status == self.STATUS_SIGNED and not self.signed_at:
            raise ValidationError(
                "Consent signed must have signed_at timestamp."
            )

    def delete(self, *args, **kwargs):
        """
        Consentimentos nunca devem ser removidos.
        Apenas revogados.
        """
        raise ValidationError(
            "Consentimentos não podem ser deletados."
        )