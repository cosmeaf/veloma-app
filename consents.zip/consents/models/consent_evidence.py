import uuid

from django.db import models
from django.core.exceptions import ValidationError


class ConsentEvidence(models.Model):
    """
    Registro forense permanente do consentimento.

    Este modelo armazena toda evidência criptográfica e
    contextual que comprova a autenticidade do consentimento.
    """

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )

    consent = models.OneToOneField(
        "consents.Consent",
        on_delete=models.CASCADE,
        related_name="evidence"
    )

    # ------------------------------------------------------------
    # DOCUMENT STORAGE
    # ------------------------------------------------------------

    document_s3_key = models.CharField(
        max_length=500,
        help_text="Chave do objeto no bucket MinIO (consent-evidence)"
    )

    document_hash_sha256 = models.CharField(
        max_length=64,
        db_index=True,
        help_text="Hash SHA256 do documento PDF gerado"
    )

    # ------------------------------------------------------------
    # DIGITAL SIGNATURE
    # ------------------------------------------------------------

    document_signature = models.TextField(
        help_text="Assinatura digital PKI (RSA 4096)"
    )

    # ------------------------------------------------------------
    # TRUSTED TIMESTAMP
    # ------------------------------------------------------------

    timestamp_token = models.TextField(
        help_text="Token RFC3161 de timestamp confiável"
    )

    # ------------------------------------------------------------
    # TERMS SNAPSHOT
    # ------------------------------------------------------------

    terms_hash_snapshot = models.CharField(
        max_length=64,
        help_text="Hash SHA256 das versões dos termos aceitos"
    )

    # ------------------------------------------------------------
    # FORENSIC SNAPSHOT
    # ------------------------------------------------------------

    snapshot_json = models.JSONField(
        help_text="Snapshot completo do ambiente do cliente no momento da assinatura"
    )

    # ------------------------------------------------------------
    # MERKLE PROOF
    # ------------------------------------------------------------

    merkle_leaf_hash = models.CharField(
        max_length=64,
        blank=True,
        help_text="Hash da folha na árvore Merkle"
    )

    # ------------------------------------------------------------
    # BLOCKCHAIN PROOF
    # ------------------------------------------------------------

    blockchain_anchor_tx = models.CharField(
        max_length=255,
        blank=True,
        help_text="Transaction ID onde o Merkle root foi ancorado"
    )

    # ------------------------------------------------------------
    # AUDIT
    # ------------------------------------------------------------

    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True
    )

    class Meta:
        db_table = "consent_evidence"

        verbose_name = "Evidência de Consentimento"
        verbose_name_plural = "Evidências de Consentimento"

        indexes = [
            models.Index(fields=["document_hash_sha256"]),
            models.Index(fields=["created_at"]),
        ]

    def __str__(self):
        return f"Evidence for {self.consent_id}"

    # ------------------------------------------------------------
    # SECURITY RULES
    # ------------------------------------------------------------

    def delete(self, *args, **kwargs):
        """
        Evidências nunca devem ser removidas.
        """
        raise ValidationError(
            "Evidências legais não podem ser deletadas."
        )