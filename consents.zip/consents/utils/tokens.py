import secrets
from .hashing import sha256_hex


def generate_secure_token(length=48) -> str:
    return secrets.token_urlsafe(length)


def hash_token(token: str) -> str:
    return sha256_hex(token)