from django.contrib import admin
from consents.models import Consent, ConsentVersion


@admin.register(Consent)
class ConsentAdmin(admin.ModelAdmin):

    list_display = (
        "client_name",
        "client_email",
        "status",
        "expires_at",
        "signed_at",
        "created_at",
    )

    list_filter = (
        "status",
        "created_at",
        "signed_at",
    )

    search_fields = (
        "client_name",
        "client_email",
        "client_tax_id",
    )

    readonly_fields = (
        "token_hash",
        "opened_at",
        "signed_at",
        "ip_open",
        "ip_signed",
        "user_agent_open",
        "user_agent_signed",
        "device_fingerprint",
        "email_sent_at",
        "last_email_sent",
        "created_at",
    )

    ordering = ("-created_at",)

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(ConsentVersion)
class ConsentVersionAdmin(admin.ModelAdmin):

    list_display = (
        "consent",
        "term",
        "term_version",
        "content_hash_snapshot",
        "created_at",
    )

    list_filter = (
        "created_at",
        "term",
    )

    search_fields = (
        "content_hash_snapshot",
    )

    readonly_fields = (
        "term_title_snapshot",
        "content_hash_snapshot",
        "created_at",
    )

    ordering = ("-created_at",)

    def has_delete_permission(self, request, obj=None):
        return False