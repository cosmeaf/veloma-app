from django.contrib import admin
from consents.models import ConsentEvidence, ConsentEvent


@admin.register(ConsentEvidence)
class ConsentEvidenceAdmin(admin.ModelAdmin):

    list_display = (
        "consent",
        "document_hash_sha256",
        "merkle_leaf_hash",
        "blockchain_anchor_tx",
        "created_at",
    )

    search_fields = (
        "document_hash_sha256",
        "blockchain_anchor_tx",
    )

    readonly_fields = (
        "consent",
        "document_s3_key",
        "document_hash_sha256",
        "document_signature",
        "timestamp_token",
        "terms_hash_snapshot",
        "snapshot_json",
        "merkle_leaf_hash",
        "blockchain_anchor_tx",
        "created_at",
    )

    ordering = ("-created_at",)

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(ConsentEvent)
class ConsentEventAdmin(admin.ModelAdmin):

    list_display = (
        "consent",
        "event_type",
        "event_hash",
        "previous_hash",
        "created_at",
    )

    list_filter = (
        "event_type",
        "created_at",
    )

    search_fields = (
        "event_hash",
    )

    readonly_fields = (
        "consent",
        "event_type",
        "metadata",
        "previous_hash",
        "event_hash",
        "created_at",
    )

    ordering = ("-created_at",)

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False