from django.contrib import admin
from consents.models import Term, TermVersion


@admin.register(Term)
class TermAdmin(admin.ModelAdmin):

    list_display = (
        "name",
        "active",
        "created_at",
    )

    list_filter = (
        "active",
        "created_at",
    )

    search_fields = (
        "name",
        "description",
    )

    readonly_fields = (
        "created_at",
        "updated_at",
    )

    ordering = ("-created_at",)


@admin.register(TermVersion)
class TermVersionAdmin(admin.ModelAdmin):

    list_display = (
        "term",
        "version",
        "active",
        "content_hash",
        "created_at",
    )

    list_filter = (
        "active",
        "created_at",
        "term",
    )

    search_fields = (
        "title",
        "content_hash",
    )

    readonly_fields = (
        "content_hash",
        "created_at",
    )

    ordering = ("-version",)

    def has_delete_permission(self, request, obj=None):
        return False